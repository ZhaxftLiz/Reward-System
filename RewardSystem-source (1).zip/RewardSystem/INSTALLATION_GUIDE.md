# RewardSystem - Installation & Build Guide

## Table of Contents
1. [Quick Start](#quick-start)
2. [Build from Source](#build-from-source)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [Usage](#usage)
6. [Troubleshooting](#troubleshooting)

---

## Quick Start

### If You Have a Pre-Built JAR:

1. **Download** `RewardSystem.jar`
2. **Place** it in: `your_server/plugins/RewardSystem.jar`
3. **Start** your server
4. **Configure** the plugin (see Configuration section)
5. **Reload** or restart the server

---

## Build from Source

### Option 1: Build with Maven (Recommended)

#### Prerequisites:
- Maven 3.6.0 or higher
- Java JDK 11 or higher
- Git (optional)

#### Steps:

1. **Extract** the RewardSystem-source.zip file:
   ```bash
   unzip RewardSystem-source.zip
   cd RewardSystem
   ```

2. **Ensure LlamaEconomy JAR is in libs folder:**
   ```bash
   mkdir -p libs
   cp /path/to/LlamaEconomy.jar libs/
   ```

3. **Build the plugin:**
   ```bash
   mvn clean package
   ```

4. **Find the JAR:**
   ```bash
   ls target/RewardSystem.jar
   ```

5. **Copy to server:**
   ```bash
   cp target/RewardSystem.jar /path/to/server/plugins/
   ```

### Option 2: Build with Script (Linux/Mac)

1. **Extract** the RewardSystem-source.zip:
   ```bash
   unzip RewardSystem-source.zip
   cd RewardSystem
   ```

2. **Make build script executable:**
   ```bash
   chmod +x build.sh
   ```

3. **Run build script:**
   ```bash
   ./build.sh
   ```

4. **Copy JAR to server:**
   ```bash
   cp target/RewardSystem.jar /path/to/server/plugins/
   ```

### Option 3: Build with Script (Windows)

1. **Extract** the RewardSystem-source.zip

2. **Open Command Prompt** and navigate to RewardSystem folder:
   ```cmd
   cd RewardSystem
   ```

3. **Run build script:**
   ```cmd
   build.bat
   ```

4. **Copy JAR to server:**
   - Copy `target/RewardSystem.jar` to `your_server/plugins/`

---

## Installation

### Server Requirements:
- PowerNukkitX 3.0.3 or higher
- LlamaEconomy plugin installed and enabled
- Java 11 or higher

### Installation Steps:

1. **Stop your server** (if running)

2. **Create plugins folder** (if doesn't exist):
   ```
   your_server/plugins/
   ```

3. **Place RewardSystem.jar:**
   ```
   your_server/plugins/RewardSystem.jar
   ```

4. **Start your server:**
   ```bash
   # Linux/Mac
   ./start.sh
   
   # Windows
   start.bat
   ```

5. **Verify installation:**
   ```
   [INFO] [RewardSystem] ✓ RewardSystem plugin enabled successfully!
   [INFO] [RewardSystem] ✓ LlamaEconomy integrated!
   ```

---

## Configuration

### File Locations:
```
your_server/
├── plugins/
│   ├── RewardSystem.jar
│   └── RewardSystem/
│       ├── config.yml      (Main configuration)
│       ├── messages.yml    (Customizable messages)
│       └── player-data/    (Player data files)
```

### Basic Configuration (config.yml)

```yaml
rewards:
  daily:
    money: 1000              # Money per claim
    streak-bonus: 100        # Bonus per consecutive day
    items:                   # Optional items to give
      # apple: 5
      # diamond: 1
  
  weekly:
    money: 5000
    streak-bonus: 500
    items:
      # diamond: 2
  
  monthly:
    money: 15000
    streak-bonus: 2000
    items:
      # emerald: 5
```

### Customizing Messages (messages.yml)

Edit the messages file to customize all plugin messages:

```yaml
messages:
  daily-claim-success: "§a✓ You claimed your daily reward!"
  no-permission: "§cYou don't have permission to use this command!"
  # ... more customizations
```

### Color Codes Reference

```
§0 = Black       §8 = Dark Gray
§1 = Dark Blue   §9 = Blue
§2 = Dark Green  §a = Green
§3 = Dark Aqua   §b = Aqua
§4 = Dark Red    §c = Red
§5 = Purple      §d = Light Purple
§6 = Gold        §e = Yellow
§7 = Gray        §f = White

§l = Bold        §n = Underline
§o = Italic      §m = Strikethrough
§r = Reset
```

### Valid Item Names

Common items:
```
apple, diamond, emerald, iron_ingot, gold_ingot,
oak_log, oak_planks, stone, dirt, cobblestone,
diamond_pickaxe, iron_sword, golden_apple,
ender_pearl, blaze_rod, magma_cream, etc.
```

Or use item IDs: `"264:0"` (diamond)

---

## Usage

### For Players

**Open Reward Menu:**
```
/reward
```

**View Player Stats:**
```
/reward info <player>          (Admin only)
```

### For Admins

**Reload Configuration:**
```
/reward reload
```

**Reset Player Rewards:**
```
/reward reset <player>
```

**View Player Information:**
```
/reward info <player>
```

---

## Troubleshooting

### Problem: Plugin doesn't enable

**Solution:**
1. Check LlamaEconomy is installed: `/plugins`
2. Check console for errors
3. Verify Java version: `java -version` (need Java 11+)
4. Check file permissions

### Problem: Rewards not giving money

**Solution:**
1. Verify LlamaEconomy is working
2. Check economy logs
3. Test with: `/money add PlayerName 100`
4. Check configuration values are valid

### Problem: Player data not saving

**Solution:**
1. Check file permissions on plugins folder
2. Verify `/plugins/RewardSystem/player-data/` exists
3. Check disk space available
4. Look for file I/O errors in console

### Problem: GUI/Forms not showing

**Solution:**
1. Ensure client supports forms
2. Check player is using modern Minecraft version
3. Try closing and reopening inventory
4. Check server-side logs for errors

### Problem: Cooldown times incorrect

**Solution:**
1. Check server system time is correct
2. Verify system timezone settings
3. Reload plugin: `/reward reload`
4. Check player data file timestamps

### Common Error Messages

| Error | Cause | Solution |
|-------|-------|----------|
| `LlamaEconomy not found` | Plugin not installed | Install LlamaEconomy |
| `No permission to use this` | Missing permission node | Grant permission to player |
| `Unknown command` | Command misspelled | Check command spelling |
| `Player data not found` | New player | Data auto-created on first use |

---

## File Structure

```
RewardSystem/
├── src/
│   └── main/
│       ├── java/
│       │   └── com/rewardsystem/
│       │       ├── RewardSystem.java        (Main class)
│       │       ├── commands/
│       │       │   └── RewardCommand.java   (Command handler)
│       │       ├── managers/
│       │       │   ├── ConfigurationManager.java
│       │       │   ├── RewardDataManager.java
│       │       │   ├── RewardManager.java
│       │       │   └── CooldownManager.java
│       │       ├── models/
│       │       │   └── PlayerRewardData.java
│       │       ├── gui/
│       │       │   └── RewardMenu.java
│       │       ├── hooks/
│       │       │   └── EconomyHook.java
│       │       └── listeners/
│       │           ├── PlayerJoinListener.java
│       │           └── PlayerQuitListener.java
│       └── resources/
│           ├── config.yml
│           ├── messages.yml
│           └── plugin.yml
├── pom.xml                 (Maven configuration)
├── build.sh               (Linux/Mac build script)
├── build.bat              (Windows build script)
├── README.md              (Plugin documentation)
└── INSTALLATION_GUIDE.md  (This file)
```

---

## Next Steps

1. **Configure rewards** in `config.yml`
2. **Customize messages** in `messages.yml`
3. **Test with players** on your server
4. **Adjust settings** based on gameplay

---

## Support

For detailed information:
- Check README.md
- Review console logs for errors
- Verify configuration files are valid YAML
- Test permissions with: `/permission check @s rewardsystem.use`

---

**Enjoy the RewardSystem plugin!** 🎉
