@echo off
REM RewardSystem Build Script for Windows
REM This script compiles the plugin without Maven

echo =========================================
echo RewardSystem Plugin Build Script
echo =========================================

setlocal enabledelayedexpansion

REM Set variables
set PROJECT_DIR=%~dp0
set SRC_DIR=%PROJECT_DIR%src\main\java
set RESOURCES_DIR=%PROJECT_DIR%src\main\resources
set TARGET_DIR=%PROJECT_DIR%target
set BUILD_CLASS_DIR=%TARGET_DIR%\classes
set LIB_DIR=%PROJECT_DIR%libs
set JAR_NAME=RewardSystem.jar

echo Creating directories...
if not exist "%BUILD_CLASS_DIR%" mkdir "%BUILD_CLASS_DIR%"

echo Checking Java version...
for /f "tokens=*" %%i in ('javac -version 2^>^&1') do set JAVA_VERSION=%%i
if "%JAVA_VERSION%"=="" (
    echo ERROR: javac not found! Please install Java JDK 11 or higher.
    exit /b 1
)
echo Found: %JAVA_VERSION%

echo Compiling Java files...
cd /d "%PROJECT_DIR%"
javac -d "%BUILD_CLASS_DIR%" -cp "%LIB_DIR%\*" @java_sources.txt 2>build_error.log
if errorlevel 1 (
    echo Compilation failed!
    type build_error.log
    exit /b 1
)

echo Compilation successful!

echo Copying resources...
xcopy "%RESOURCES_DIR%" "%BUILD_CLASS_DIR%" /E /I /Y >nul 2>&1

echo Creating JAR file...
pushd "%BUILD_CLASS_DIR%"
jar cf "%TARGET_DIR%\%JAR_NAME%" .
popd

if errorlevel 1 (
    echo Error creating JAR file!
    exit /b 1
)

echo Build successful!
echo JAR file: %TARGET_DIR%\%JAR_NAME%
echo.
echo Installation instructions:
echo 1. Copy %JAR_NAME% to your server's 'plugins' folder
echo 2. Start your server
echo 3. Configure the plugin in 'plugins/RewardSystem/'
echo.

endlocal
