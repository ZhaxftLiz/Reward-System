#!/bin/bash

# RewardSystem Build Script
# This script compiles the plugin without Maven

echo "========================================="
echo "RewardSystem Plugin Build Script"
echo "========================================="

# Set variables
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$PROJECT_DIR/src/main/java"
RESOURCES_DIR="$PROJECT_DIR/src/main/resources"
TARGET_DIR="$PROJECT_DIR/target"
BUILD_CLASS_DIR="$TARGET_DIR/classes"
LIB_DIR="$PROJECT_DIR/libs"
JAR_NAME="RewardSystem.jar"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Create target directories
echo -e "${YELLOW}Creating directories...${NC}"
mkdir -p "$BUILD_CLASS_DIR"

# Check Java
echo -e "${YELLOW}Checking Java version...${NC}"
if ! command -v javac &> /dev/null; then
    echo -e "${RED}ERROR: javac not found! Please install Java JDK 11 or higher.${NC}"
    exit 1
fi

JAVA_VERSION=$(javac -version 2>&1 | head -1)
echo -e "${GREEN}Found: $JAVA_VERSION${NC}"

# Compile Java files
echo -e "${YELLOW}Compiling Java files...${NC}"
javac -d "$BUILD_CLASS_DIR" \
    -cp "$LIB_DIR/*" \
    $(find "$SRC_DIR" -name "*.java") \
    2>&1

if [ $? -ne 0 ]; then
    echo -e "${RED}Compilation failed!${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Compilation successful!${NC}"

# Copy resources
echo -e "${YELLOW}Copying resources...${NC}"
cp -r "$RESOURCES_DIR"/* "$BUILD_CLASS_DIR/" 2>/dev/null

# Create JAR file
echo -e "${YELLOW}Creating JAR file...${NC}"
cd "$BUILD_CLASS_DIR"
jar cf "$TARGET_DIR/$JAR_NAME" .
cd "$PROJECT_DIR"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Build successful!${NC}"
    echo -e "${GREEN}JAR file: $TARGET_DIR/$JAR_NAME${NC}"
    echo ""
    echo -e "${YELLOW}Installation instructions:${NC}"
    echo "1. Copy $JAR_NAME to your server's 'plugins' folder"
    echo "2. Start your server"
    echo "3. Configure the plugin in 'plugins/RewardSystem/'"
    echo ""
else
    echo -e "${RED}Error creating JAR file!${NC}"
    exit 1
fi
