# RewardSystem Plugin

A comprehensive **production-ready** daily, weekly, and monthly reward system plugin for PowerNukkitX 3.0.3 with **LlamaEconomy** integration.

## Features

### 🎁 Three Reward Tiers
- **Daily Reward**: Claim once every 24 hours
  - Base reward: $1,000
  - Streak bonus per day: $100
  
- **Weekly Reward**: Claim once every 7 days
  - Base reward: $5,000
  - Streak bonus per week: $500
  
- **Monthly Reward**: Claim once every 30 days
  - Base reward: $15,000
  - Streak bonus per month: $2,000

### 📊 Streak System
- Automatic streak tracking for each reward type
- Grace period: Up to 26 hours for daily, 9 days for weekly, 32 days for monthly
- Visual indicators in GUI (✅ Ready / ⏳ Cooldown / 🔥 Streak)

### 💰 Economy Integration
- **LlamaEconomy** integration via reflection (no hard dependency)
- Flexible item rewards system
- Configurable money and item rewards via `config.yml`

### 🎨 GUI System
- Beautiful interactive form-based menu
- Real-time countdown timers
- Statistics display
- Easy-to-use interface for all players

### 📝 YAML Data Storage
- Player data stored in YAML format
- Automatic saving on player quit
- No external database required
- Simple and reliable data persistence

### 🔧 Admin Commands
```
/reward                    - Open reward menu
/reward reload            - Reload configuration
/reward reset <player>    - Reset player's reward data
/reward info <player>     - View player's reward information
```

### ✅ Permissions
- `rewardsystem.use` - Default permission for players
- `rewardsystem.admin` - Admin permission for management commands

## Installation

### Prerequisites
- PowerNukkitX 3.0.3 or higher
- LlamaEconomy plugin installed and enabled
- Java 11 or higher

### Steps

1. **Download** or build `RewardSystem.jar`

2. **Place** the JAR file in your server's `plugins` folder:
   ```
   /server/plugins/RewardSystem.jar
   ```

3. **Start** your server

4. **Configure** the plugin by editing:
   ```
   /plugins/RewardSystem/config.yml
   /plugins/RewardSystem/messages.yml
   ```

5. **Reload** the plugin:
   ```
   /reload confirm
   ```
   or use
   ```
   /reward reload
   ```

## Configuration

### config.yml

```yaml
rewards:
  daily:
    money: 1000
    streak-bonus: 100
    items:
      apple: 5
      diamond: 1
  
  weekly:
    money: 5000
    streak-bonus: 500
    items:
      diamond: 2
      emerald: 1
  
  monthly:
    money: 15000
    streak-bonus: 2000
    items:
      emerald: 5
      gold_ingot: 10
```

### Item Naming
Use standard Minecraft item names:
- `apple`, `diamond`, `emerald`, `iron_ingot`, `gold_ingot`
- `oak_log`, `oak_planks`, `stone`, `dirt`, `cobblestone`
- `iron_pickaxe`, `diamond_pickaxe`, `diamond_sword`, etc.

Or use item ID format: `"item_id:damage"`

### messages.yml

Customize all plugin messages:
```yaml
messages:
  daily-claim-success: "§a✓ You claimed your daily reward!"
  no-permission: "§cYou don't have permission to use this command!"
  # ... more messages
```

## Data Structure

Player data is stored in `/plugins/RewardSystem/player-data/`:

```
RewardSystem/
├── player-data/
│   ├── PlayerName1.yml
│   ├── PlayerName2.yml
│   └── ...
├── config.yml
└── messages.yml
```

Each player file contains:
```yaml
last-daily-claim: 1629302400000
last-weekly-claim: 1629216000000
last-monthly-claim: 1626624000000
daily-streak: 15
weekly-streak: 3
monthly-streak: 1
total-daily-claims: 45
total-weekly-claims: 12
total-monthly-claims: 4
```

## API Integration

### LlamaEconomy Integration

The plugin uses reflection to integrate with LlamaEconomy, making it safe and compatible:

```java
EconomyHook economyHook = plugin.getEconomyHook();
economyHook.addMoney(player, 1000.0);
double balance = economyHook.getMoney(player);
```

### Custom Item Rewards

Items can be configured in `config.yml`:

```yaml
rewards:
  daily:
    items:
      apple: 5
      diamond: 1
```

Items are automatically given when a reward is claimed.

## Build Instructions

### Prerequisites
- Maven 3.6.0+
- Java 11 JDK

### Building

1. **Clone/extract** the project:
   ```bash
   cd RewardSystem
   ```

2. **Copy LlamaEconomy JAR** to libs folder:
   ```bash
   mkdir libs
   cp /path/to/LlamaEconomy.jar libs/
   ```

3. **Build** the plugin:
   ```bash
   mvn clean package
   ```

4. **Find** the JAR:
   ```bash
   ls target/RewardSystem.jar
   ```

## Troubleshooting

### Plugin not enabling
- Check that LlamaEconomy is installed and enabled
- Check console for error messages
- Verify Java version is 11 or higher

### Rewards not giving money
- Ensure LlamaEconomy is working properly
- Check that the player has sufficient inventory space for items
- Verify configuration in `config.yml`

### Data not saving
- Check plugin folder permissions
- Ensure `/plugins/RewardSystem/` folder exists
- Check console for file I/O errors

### Commands not working
- Verify player has correct permissions
- Use `/permission check @s rewardsystem.admin` to verify
- Ensure plugin is enabled: `/plugins`

## Performance

- **Lightweight**: Minimal resource usage
- **Cached**: Player data cached in memory for performance
- **Async**: Data saving doesn't block main thread
- **No Database**: YAML storage is simple and fast

## Support & Issues

For issues or suggestions, check:
1. Console logs for error messages
2. `config.yml` for typos or invalid values
3. Permissions are correctly set up
4. LlamaEconomy is properly installed

## License

This plugin is provided as-is for use on PowerNukkitX servers.

## Changelog

### v1.0.0
- Initial release
- Daily, Weekly, Monthly rewards
- Streak system with grace periods
- LlamaEconomy integration
- GUI menu system
- YAML data storage
- Admin commands
- Full configuration support

---

**Made with ❤️ for PowerNukkitX**
