package com.rewardsystem;

import cn.nukkit.plugin.PluginBase;
import cn.nukkit.plugin.ServicePriority;
import cn.nukkit.utils.Config;
import com.rewardsystem.commands.RewardCommand;
import com.rewardsystem.hooks.EconomyHook;
import com.rewardsystem.listeners.PlayerJoinListener;
import com.rewardsystem.listeners.PlayerQuitListener;
import com.rewardsystem.managers.ConfigurationManager;
import com.rewardsystem.managers.CooldownManager;
import com.rewardsystem.managers.RewardDataManager;
import com.rewardsystem.managers.RewardManager;

import java.io.File;
import java.util.Objects;

public class RewardSystem extends PluginBase {
    
    private static RewardSystem instance;
    private RewardDataManager dataManager;
    private RewardManager rewardManager;
    private ConfigurationManager configManager;
    private EconomyHook economyHook;
    private CooldownManager cooldownManager;
    
    @Override
    public void onLoad() {
        instance = this;
        this.getLogger().info("§aRewardSystem plugin loaded!");
    }
    
    @Override
    public void onEnable() {
        try {
            // Initialize managers
            this.configManager = new ConfigurationManager(this);
            this.dataManager = new RewardDataManager(this);
            this.cooldownManager = new CooldownManager();
            
            // Initialize economy hook
            this.economyHook = new EconomyHook(this);
            if (!economyHook.isEnabled()) {
                this.getLogger().warning("§cLlamaEconomy not found! Plugin will not function properly.");
                this.getLogger().warning("§cPlease install LlamaEconomy plugin.");
                this.setEnabled(false);
                return;
            }
            
            // Initialize reward manager
            this.rewardManager = new RewardManager(this);
            
            // Register commands
            Objects.requireNonNull(getServer().getCommandMap().register("reward", new RewardCommand(this)));
            
            // Register listeners
            getServer().getPluginManager().registerEvents(new PlayerJoinListener(this), this);
            getServer().getPluginManager().registerEvents(new PlayerQuitListener(this), this);
            
            this.getLogger().info("§a✓ RewardSystem plugin enabled successfully!");
            this.getLogger().info("§a✓ LlamaEconomy integrated!");
            this.getLogger().info("§a✓ Use /reward to open the menu!");
            
        } catch (Exception e) {
            this.getLogger().error("§cError enabling RewardSystem plugin: " + e.getMessage());
            e.printStackTrace();
            this.setEnabled(false);
        }
    }
    
    @Override
    public void onDisable() {
        try {
            if (dataManager != null) {
                dataManager.saveAllData();
            }
            this.getLogger().info("§cRewardSystem plugin disabled!");
        } catch (Exception e) {
            this.getLogger().error("§cError disabling RewardSystem plugin: " + e.getMessage());
        }
    }
    
    public static RewardSystem getInstance() {
        return instance;
    }
    
    public RewardDataManager getDataManager() {
        return dataManager;
    }
    
    public RewardManager getRewardManager() {
        return rewardManager;
    }
    
    public ConfigurationManager getConfigManager() {
        return configManager;
    }
    
    public EconomyHook getEconomyHook() {
        return economyHook;
    }
    
    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }
}
