package com.rewardsystem.gui;

import cn.nukkit.Player;
import cn.nukkit.form.element.ElementButton;
import cn.nukkit.form.element.ElementButtonImageData;
import cn.nukkit.form.response.FormResponseSimple;
import cn.nukkit.form.window.FormWindowSimple;
import com.rewardsystem.RewardSystem;
import com.rewardsystem.models.PlayerRewardData;

public class RewardMenu {
    
    private RewardSystem plugin;
    
    public RewardMenu(RewardSystem plugin) {
        this.plugin = plugin;
    }
    
    public void openMainMenu(Player player) {
        FormWindowSimple form = new FormWindowSimple(
            "§l§6Reward System",
            "§7Select a reward to claim!"
        );
        
        PlayerRewardData data = plugin.getDataManager().getPlayerData(player.getName());
        
        // Daily Reward Button
        String dailyStatus = getDailyStatus(player);
        form.addButton(new ElementButton("§6Daily Reward\n" + dailyStatus));
        
        // Weekly Reward Button
        String weeklyStatus = getWeeklyStatus(player);
        form.addButton(new ElementButton("§5Weekly Reward\n" + weeklyStatus));
        
        // Monthly Reward Button
        String monthlyStatus = getMonthlyStatus(player);
        form.addButton(new ElementButton("§cMonthly Reward\n" + monthlyStatus));
        
        // Info Button
        form.addButton(new ElementButton("§eView Statistics"));
        
        form.setCallbackFunction((p, response) -> {
            if (response != null && response instanceof FormResponseSimple) {
                FormResponseSimple simpleResponse = (FormResponseSimple) response;
                int clickedButton = simpleResponse.getClickedButtonId();
                
                handleMenuClick(p, clickedButton);
            }
        });
        
        player.showFormWindow(form);
    }
    
    private void handleMenuClick(Player player, int buttonId) {
        switch (buttonId) {
            case 0: // Daily Reward
                claimDailyMenu(player);
                break;
            case 1: // Weekly Reward
                claimWeeklyMenu(player);
                break;
            case 2: // Monthly Reward
                claimMonthlyMenu(player);
                break;
            case 3: // Statistics
                showStatistics(player);
                break;
        }
    }
    
    private void claimDailyMenu(Player player) {
        long remainingTime = plugin.getRewardManager().getRemainingDailyTime(player);
        
        if (remainingTime <= 0) {
            // Can claim
            FormWindowSimple form = new FormWindowSimple(
                "§6Daily Reward",
                "§aYou can claim your daily reward now!\n\n" +
                "§7Money: §6+" + plugin.getConfigManager().getDailyRewardMoney() + "\n" +
                "§7Streak Bonus: §6+" + (plugin.getDataManager().getPlayerData(player.getName()).getDailyStreak() * plugin.getConfigManager().getDailyRewardStreakBonus())
            );
            
            form.addButton(new ElementButton("§a✓ Claim Now"));
            form.addButton(new ElementButton("§7Back"));
            
            form.setCallbackFunction((p, response) -> {
                if (response != null && response instanceof FormResponseSimple) {
                    FormResponseSimple simpleResponse = (FormResponseSimple) response;
                    if (simpleResponse.getClickedButtonId() == 0) {
                        if (plugin.getRewardManager().claimDailyReward(p)) {
                            p.sendMessage(plugin.getConfigManager().getMessage("messages.daily-claim-success"));
                        }
                    } else {
                        openMainMenu(p);
                    }
                }
            });
            
            player.showFormWindow(form);
        } else {
            // On cooldown
            String timeRemaining = plugin.getCooldownManager().formatTime(remainingTime);
            FormWindowSimple form = new FormWindowSimple(
                "§6Daily Reward",
                "§c⏳ You need to wait before claiming again.\n\n" +
                "§7Time remaining: §c" + timeRemaining
            );
            
            form.addButton(new ElementButton("§7Back"));
            
            form.setCallbackFunction((p, response) -> {
                openMainMenu(p);
            });
            
            player.showFormWindow(form);
        }
    }
    
    private void claimWeeklyMenu(Player player) {
        long remainingTime = plugin.getRewardManager().getRemainingWeeklyTime(player);
        
        if (remainingTime <= 0) {
            FormWindowSimple form = new FormWindowSimple(
                "§5Weekly Reward",
                "§aYou can claim your weekly reward now!\n\n" +
                "§7Money: §6+" + plugin.getConfigManager().getWeeklyRewardMoney() + "\n" +
                "§7Streak Bonus: §6+" + (plugin.getDataManager().getPlayerData(player.getName()).getWeeklyStreak() * plugin.getConfigManager().getWeeklyRewardStreakBonus())
            );
            
            form.addButton(new ElementButton("§a✓ Claim Now"));
            form.addButton(new ElementButton("§7Back"));
            
            form.setCallbackFunction((p, response) -> {
                if (response != null && response instanceof FormResponseSimple) {
                    FormResponseSimple simpleResponse = (FormResponseSimple) response;
                    if (simpleResponse.getClickedButtonId() == 0) {
                        if (plugin.getRewardManager().claimWeeklyReward(p)) {
                            p.sendMessage(plugin.getConfigManager().getMessage("messages.weekly-claim-success"));
                        }
                    } else {
                        openMainMenu(p);
                    }
                }
            });
            
            player.showFormWindow(form);
        } else {
            String timeRemaining = plugin.getCooldownManager().formatTime(remainingTime);
            FormWindowSimple form = new FormWindowSimple(
                "§5Weekly Reward",
                "§c⏳ You need to wait before claiming again.\n\n" +
                "§7Time remaining: §c" + timeRemaining
            );
            
            form.addButton(new ElementButton("§7Back"));
            
            form.setCallbackFunction((p, response) -> {
                openMainMenu(p);
            });
            
            player.showFormWindow(form);
        }
    }
    
    private void claimMonthlyMenu(Player player) {
        long remainingTime = plugin.getRewardManager().getRemainingMonthlyTime(player);
        
        if (remainingTime <= 0) {
            FormWindowSimple form = new FormWindowSimple(
                "§cMonthly Reward",
                "§aYou can claim your monthly reward now!\n\n" +
                "§7Money: §6+" + plugin.getConfigManager().getMonthlyRewardMoney() + "\n" +
                "§7Streak Bonus: §6+" + (plugin.getDataManager().getPlayerData(player.getName()).getMonthlyStreak() * plugin.getConfigManager().getMonthlyRewardStreakBonus())
            );
            
            form.addButton(new ElementButton("§a✓ Claim Now"));
            form.addButton(new ElementButton("§7Back"));
            
            form.setCallbackFunction((p, response) -> {
                if (response != null && response instanceof FormResponseSimple) {
                    FormResponseSimple simpleResponse = (FormResponseSimple) response;
                    if (simpleResponse.getClickedButtonId() == 0) {
                        if (plugin.getRewardManager().claimMonthlyReward(p)) {
                            p.sendMessage(plugin.getConfigManager().getMessage("messages.monthly-claim-success"));
                        }
                    } else {
                        openMainMenu(p);
                    }
                }
            });
            
            player.showFormWindow(form);
        } else {
            String timeRemaining = plugin.getCooldownManager().formatTime(remainingTime);
            FormWindowSimple form = new FormWindowSimple(
                "§cMonthly Reward",
                "§c⏳ You need to wait before claiming again.\n\n" +
                "§7Time remaining: §c" + timeRemaining
            );
            
            form.addButton(new ElementButton("§7Back"));
            
            form.setCallbackFunction((p, response) -> {
                openMainMenu(p);
            });
            
            player.showFormWindow(form);
        }
    }
    
    private void showStatistics(Player player) {
        PlayerRewardData data = plugin.getDataManager().getPlayerData(player.getName());
        
        String stats = "§7Total Daily Claims: §6" + data.getTotalDailyClaims() + "\n" +
                       "§7Total Weekly Claims: §6" + data.getTotalWeeklyClaims() + "\n" +
                       "§7Total Monthly Claims: §6" + data.getTotalMonthlyClaims() + "\n\n" +
                       "§7Current Daily Streak: §6" + data.getDailyStreak() + " §7(🔥)\n" +
                       "§7Current Weekly Streak: §6" + data.getWeeklyStreak() + " §7(🔥)\n" +
                       "§7Current Monthly Streak: §6" + data.getMonthlyStreak() + " §7(🔥)";
        
        FormWindowSimple form = new FormWindowSimple(
            "§eStatistics",
            stats
        );
        
        form.addButton(new ElementButton("§7Back"));
        
        form.setCallbackFunction((p, response) -> {
            openMainMenu(p);
        });
        
        player.showFormWindow(form);
    }
    
    private String getDailyStatus(Player player) {
        long remaining = plugin.getRewardManager().getRemainingDailyTime(player);
        if (remaining <= 0) {
            return "§a✓ Ready to Claim";
        } else {
            String timeLeft = plugin.getCooldownManager().formatTime(remaining);
            return "§c⏳ " + timeLeft;
        }
    }
    
    private String getWeeklyStatus(Player player) {
        long remaining = plugin.getRewardManager().getRemainingWeeklyTime(player);
        if (remaining <= 0) {
            return "§a✓ Ready to Claim";
        } else {
            String timeLeft = plugin.getCooldownManager().formatTime(remaining);
            return "§c⏳ " + timeLeft;
        }
    }
    
    private String getMonthlyStatus(Player player) {
        long remaining = plugin.getRewardManager().getRemainingMonthlyTime(player);
        if (remaining <= 0) {
            return "§a✓ Ready to Claim";
        } else {
            String timeLeft = plugin.getCooldownManager().formatTime(remaining);
            return "§c⏳ " + timeLeft;
        }
    }
}
