package com.rewardsystem.hooks;

import cn.nukkit.Player;
import cn.nukkit.plugin.Plugin;
import cn.nukkit.plugin.PluginBase;

public class EconomyHook {
    
    private PluginBase plugin;
    private Plugin economyPlugin;
    private Object apiInstance;
    private boolean enabled = false;
    
    public EconomyHook(PluginBase plugin) {
        this.plugin = plugin;
        initializeEconomy();
    }
    
    private void initializeEconomy() {
        try {
            // Try to get LlamaEconomy plugin
            Plugin loadedPlugin = plugin.getServer().getPluginManager().getPlugin("LlamaEconomy");
            
            if (loadedPlugin != null && loadedPlugin.isEnabled()) {
                this.economyPlugin = loadedPlugin;
                
                // Try to access API
                try {
                    Class<?> apiClass = Class.forName("net.lldv.llamaeconomy.components.api.API");
                    java.lang.reflect.Method method = apiClass.getMethod("getInstance");
                    this.apiInstance = method.invoke(null);
                    
                    this.enabled = true;
                    plugin.getLogger().info("§a✓ LlamaEconomy API initialized successfully!");
                } catch (Exception e) {
                    plugin.getLogger().warning("§cCould not access LlamaEconomy API: " + e.getMessage());
                    this.enabled = false;
                }
            } else {
                plugin.getLogger().warning("§cLlamaEconomy plugin not found!");
                this.enabled = false;
            }
        } catch (Exception e) {
            plugin.getLogger().error("§cError initializing economy hook: " + e.getMessage());
            this.enabled = false;
        }
    }
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void addMoney(Player player, double amount) {
        if (!enabled || apiInstance == null) {
            return;
        }
        
        try {
            Class<?> apiClass = apiInstance.getClass();
            java.lang.reflect.Method addMoneyMethod = apiClass.getMethod("addMoney", Player.class, Double.TYPE);
            addMoneyMethod.invoke(apiInstance, player, amount);
        } catch (Exception e) {
            plugin.getLogger().error("§cError adding money to player: " + e.getMessage());
        }
    }
    
    public void setMoney(Player player, double amount) {
        if (!enabled || apiInstance == null) {
            return;
        }
        
        try {
            Class<?> apiClass = apiInstance.getClass();
            java.lang.reflect.Method setMoneyMethod = apiClass.getMethod("setMoney", Player.class, Double.TYPE);
            setMoneyMethod.invoke(apiInstance, player, amount);
        } catch (Exception e) {
            plugin.getLogger().error("§cError setting money for player: " + e.getMessage());
        }
    }
    
    public double getMoney(Player player) {
        if (!enabled || apiInstance == null) {
            return 0.0;
        }
        
        try {
            Class<?> apiClass = apiInstance.getClass();
            java.lang.reflect.Method getMoneyMethod = apiClass.getMethod("getMoney", Player.class);
            Object result = getMoneyMethod.invoke(apiInstance, player);
            
            if (result instanceof Number) {
                return ((Number) result).doubleValue();
            }
            return 0.0;
        } catch (Exception e) {
            plugin.getLogger().error("§cError getting money from player: " + e.getMessage());
            return 0.0;
        }
    }
    
    public String getCurrencySymbol() {
        if (!enabled || apiInstance == null) {
            return "$";
        }
        
        try {
            Class<?> apiClass = apiInstance.getClass();
            java.lang.reflect.Method methodSymbol = apiClass.getMethod("getCurrencySymbol");
            Object result = methodSymbol.invoke(apiInstance);
            
            if (result instanceof String) {
                return (String) result;
            }
            return "$";
        } catch (Exception e) {
            return "$";
        }
    }
}
