package com.rewardsystem.listeners;

import cn.nukkit.event.EventHandler;
import cn.nukkit.event.EventPriority;
import cn.nukkit.event.Listener;
import cn.nukkit.event.player.PlayerQuitEvent;
import com.rewardsystem.RewardSystem;

public class PlayerQuitListener implements Listener {
    
    private RewardSystem plugin;
    
    public PlayerQuitListener(RewardSystem plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerQuit(PlayerQuitEvent event) {
        String playerName = event.getPlayer().getName();
        
        try {
            // Save and unload player data when they quit
            plugin.getDataManager().unloadPlayerData(playerName);
            plugin.getLogger().debug("Unloaded reward data for player: " + playerName);
        } catch (Exception e) {
            plugin.getLogger().error("Error saving reward data for player " + playerName + ": " + e.getMessage());
        }
    }
}
