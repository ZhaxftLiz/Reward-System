package com.rewardsystem.listeners;

import cn.nukkit.event.EventHandler;
import cn.nukkit.event.EventPriority;
import cn.nukkit.event.Listener;
import cn.nukkit.event.player.PlayerJoinEvent;
import cn.nukkit.plugin.PluginBase;
import com.rewardsystem.RewardSystem;

public class PlayerJoinListener implements Listener {
    
    private RewardSystem plugin;
    
    public PlayerJoinListener(RewardSystem plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerJoin(PlayerJoinEvent event) {
        String playerName = event.getPlayer().getName();
        
        try {
            // Load player data when they join
            plugin.getDataManager().getPlayerData(playerName);
            plugin.getLogger().debug("Loaded reward data for player: " + playerName);
        } catch (Exception e) {
            plugin.getLogger().error("Error loading reward data for player " + playerName + ": " + e.getMessage());
        }
    }
}
