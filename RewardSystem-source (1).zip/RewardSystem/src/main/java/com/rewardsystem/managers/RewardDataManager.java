package com.rewardsystem.managers;

import cn.nukkit.plugin.PluginBase;
import cn.nukkit.utils.Config;
import com.rewardsystem.models.PlayerRewardData;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class RewardDataManager {
    
    private PluginBase plugin;
    private File dataFolder;
    private Map<String, PlayerRewardData> playerCache;
    
    public RewardDataManager(PluginBase plugin) {
        this.plugin = plugin;
        this.playerCache = new HashMap<>();
        
        // Create data folder
        this.dataFolder = new File(plugin.getDataFolder(), "player-data");
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
    }
    
    public PlayerRewardData getPlayerData(String playerName) {
        if (playerCache.containsKey(playerName)) {
            return playerCache.get(playerName);
        }
        
        File dataFile = new File(dataFolder, playerName + ".yml");
        PlayerRewardData data;
        
        if (dataFile.exists()) {
            try {
                Config config = new Config(dataFile, Config.YAML);
                data = new PlayerRewardData(playerName);
                
                data.setLastDailyClaim(config.getLong("last-daily-claim", 0));
                data.setLastWeeklyClaim(config.getLong("last-weekly-claim", 0));
                data.setLastMonthlyClaim(config.getLong("last-monthly-claim", 0));
                data.setDailyStreak(config.getInt("daily-streak", 0));
                data.setWeeklyStreak(config.getInt("weekly-streak", 0));
                data.setMonthlyStreak(config.getInt("monthly-streak", 0));
                data.setTotalDailyClaims(config.getInt("total-daily-claims", 0));
                data.setTotalWeeklyClaims(config.getInt("total-weekly-claims", 0));
                data.setTotalMonthlyClaims(config.getInt("total-monthly-claims", 0));
                
            } catch (Exception e) {
                plugin.getLogger().error("Error loading player data for " + playerName + ": " + e.getMessage());
                data = new PlayerRewardData(playerName);
            }
        } else {
            data = new PlayerRewardData(playerName);
        }
        
        playerCache.put(playerName, data);
        return data;
    }
    
    public void savePlayerData(String playerName) {
        if (!playerCache.containsKey(playerName)) {
            return;
        }
        
        PlayerRewardData data = playerCache.get(playerName);
        File dataFile = new File(dataFolder, playerName + ".yml");
        
        try {
            Map<String, Object> content = new HashMap<>();
            content.put("last-daily-claim", data.getLastDailyClaim());
            content.put("last-weekly-claim", data.getLastWeeklyClaim());
            content.put("last-monthly-claim", data.getLastMonthlyClaim());
            content.put("daily-streak", data.getDailyStreak());
            content.put("weekly-streak", data.getWeeklyStreak());
            content.put("monthly-streak", data.getMonthlyStreak());
            content.put("total-daily-claims", data.getTotalDailyClaims());
            content.put("total-weekly-claims", data.getTotalWeeklyClaims());
            content.put("total-monthly-claims", data.getTotalMonthlyClaims());
            
            Config config = new Config(dataFile, Config.YAML);
            config.setAll(content);
            config.save();
            
        } catch (Exception e) {
            plugin.getLogger().error("Error saving player data for " + playerName + ": " + e.getMessage());
        }
    }
    
    public void saveAllData() {
        for (String playerName : playerCache.keySet()) {
            savePlayerData(playerName);
        }
    }
    
    public void unloadPlayerData(String playerName) {
        if (playerCache.containsKey(playerName)) {
            savePlayerData(playerName);
            playerCache.remove(playerName);
        }
    }
    
    public void resetPlayerData(String playerName) {
        PlayerRewardData data = new PlayerRewardData(playerName);
        playerCache.put(playerName, data);
        savePlayerData(playerName);
    }
}
