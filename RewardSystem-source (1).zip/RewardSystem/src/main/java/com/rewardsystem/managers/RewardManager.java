package com.rewardsystem.managers;

import cn.nukkit.Player;
import cn.nukkit.item.Item;
import cn.nukkit.plugin.PluginBase;
import com.rewardsystem.RewardSystem;
import com.rewardsystem.models.PlayerRewardData;

import java.util.Map;
import java.util.Random;

public class RewardManager {
    
    private RewardSystem plugin;
    private Random random = new Random();
    
    public RewardManager(RewardSystem plugin) {
        this.plugin = plugin;
    }
    
    public boolean claimDailyReward(Player player) {
        PlayerRewardData data = plugin.getDataManager().getPlayerData(player.getName());
        
        if (!plugin.getCooldownManager().canClaimDaily(data.getLastDailyClaim())) {
            return false;
        }
        
        // Check if streak is still valid (24 hours)
        long now = System.currentTimeMillis();
        long lastClaim = data.getLastDailyClaim();
        long elapsedTime = now - lastClaim;
        long streakWindow = 26 * 60 * 60 * 1000; // 26 hours grace period
        
        if (lastClaim > 0 && elapsedTime > streakWindow) {
            // Streak reset
            data.setDailyStreak(0);
        }
        
        // Give reward
        int baseMoney = plugin.getConfigManager().getDailyRewardMoney();
        int streakBonus = data.getDailyStreak() * plugin.getConfigManager().getDailyRewardStreakBonus();
        int totalMoney = baseMoney + streakBonus;
        
        plugin.getEconomyHook().addMoney(player, totalMoney);
        
        // Update streak
        data.setDailyStreak(data.getDailyStreak() + 1);
        data.setLastDailyClaim(now);
        data.setTotalDailyClaims(data.getTotalDailyClaims() + 1);
        
        // Give items
        giveRewardItems(player, "daily");
        
        // Save data
        plugin.getDataManager().savePlayerData(player.getName());
        
        return true;
    }
    
    public boolean claimWeeklyReward(Player player) {
        PlayerRewardData data = plugin.getDataManager().getPlayerData(player.getName());
        
        if (!plugin.getCooldownManager().canClaimWeekly(data.getLastWeeklyClaim())) {
            return false;
        }
        
        // Check if streak is still valid (7 days + grace period)
        long now = System.currentTimeMillis();
        long lastClaim = data.getLastWeeklyClaim();
        long elapsedTime = now - lastClaim;
        long streakWindow = 9 * 24 * 60 * 60 * 1000; // 9 days grace period
        
        if (lastClaim > 0 && elapsedTime > streakWindow) {
            data.setWeeklyStreak(0);
        }
        
        // Give reward
        int baseMoney = plugin.getConfigManager().getWeeklyRewardMoney();
        int streakBonus = data.getWeeklyStreak() * plugin.getConfigManager().getWeeklyRewardStreakBonus();
        int totalMoney = baseMoney + streakBonus;
        
        plugin.getEconomyHook().addMoney(player, totalMoney);
        
        // Update streak
        data.setWeeklyStreak(data.getWeeklyStreak() + 1);
        data.setLastWeeklyClaim(now);
        data.setTotalWeeklyClaims(data.getTotalWeeklyClaims() + 1);
        
        // Give items
        giveRewardItems(player, "weekly");
        
        // Save data
        plugin.getDataManager().savePlayerData(player.getName());
        
        return true;
    }
    
    public boolean claimMonthlyReward(Player player) {
        PlayerRewardData data = plugin.getDataManager().getPlayerData(player.getName());
        
        if (!plugin.getCooldownManager().canClaimMonthly(data.getLastMonthlyClaim())) {
            return false;
        }
        
        // Check if streak is still valid (30 days + grace period)
        long now = System.currentTimeMillis();
        long lastClaim = data.getLastMonthlyClaim();
        long elapsedTime = now - lastClaim;
        long streakWindow = 32 * 24 * 60 * 60 * 1000; // 32 days grace period
        
        if (lastClaim > 0 && elapsedTime > streakWindow) {
            data.setMonthlyStreak(0);
        }
        
        // Give reward
        int baseMoney = plugin.getConfigManager().getMonthlyRewardMoney();
        int streakBonus = data.getMonthlyStreak() * plugin.getConfigManager().getMonthlyRewardStreakBonus();
        int totalMoney = baseMoney + streakBonus;
        
        plugin.getEconomyHook().addMoney(player, totalMoney);
        
        // Update streak
        data.setMonthlyStreak(data.getMonthlyStreak() + 1);
        data.setLastMonthlyClaim(now);
        data.setTotalMonthlyClaims(data.getTotalMonthlyClaims() + 1);
        
        // Give items
        giveRewardItems(player, "monthly");
        
        // Save data
        plugin.getDataManager().savePlayerData(player.getName());
        
        return true;
    }
    
    private void giveRewardItems(Player player, String type) {
        try {
            Object itemsObj = null;
            
            if (type.equals("daily")) {
                itemsObj = plugin.getConfigManager().getDailyRewardItems();
            } else if (type.equals("weekly")) {
                itemsObj = plugin.getConfigManager().getWeeklyRewardItems();
            } else if (type.equals("monthly")) {
                itemsObj = plugin.getConfigManager().getMonthlyRewardItems();
            }
            
            if (itemsObj instanceof Map) {
                Map<String, Object> itemsMap = (Map<String, Object>) itemsObj;
                
                for (Map.Entry<String, Object> entry : itemsMap.entrySet()) {
                    try {
                        String itemName = entry.getKey();
                        int quantity = 1;
                        
                        if (entry.getValue() instanceof Integer) {
                            quantity = (Integer) entry.getValue();
                        } else if (entry.getValue() instanceof String) {
                            try {
                                quantity = Integer.parseInt((String) entry.getValue());
                            } catch (NumberFormatException e) {
                                quantity = 1;
                            }
                        }
                        
                        Item item = Item.fromString(itemName);
                        if (item != null && item.getId() != 0) {
                            item.setCount(quantity);
                            player.getInventory().addItem(item);
                        }
                    } catch (Exception e) {
                        plugin.getLogger().warning("Error giving item reward: " + e.getMessage());
                    }
                }
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Error processing reward items: " + e.getMessage());
        }
    }
    
    public long getRemainingDailyTime(Player player) {
        PlayerRewardData data = plugin.getDataManager().getPlayerData(player.getName());
        return plugin.getCooldownManager().getRemainingDailyTime(data.getLastDailyClaim());
    }
    
    public long getRemainingWeeklyTime(Player player) {
        PlayerRewardData data = plugin.getDataManager().getPlayerData(player.getName());
        return plugin.getCooldownManager().getRemainingWeeklyTime(data.getLastWeeklyClaim());
    }
    
    public long getRemainingMonthlyTime(Player player) {
        PlayerRewardData data = plugin.getDataManager().getPlayerData(player.getName());
        return plugin.getCooldownManager().getRemainingMonthlyTime(data.getLastMonthlyClaim());
    }
}
