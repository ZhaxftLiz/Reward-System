package com.rewardsystem.managers;

import cn.nukkit.plugin.PluginBase;
import cn.nukkit.utils.Config;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

public class ConfigurationManager {
    
    private PluginBase plugin;
    private Config config;
    private Config messages;
    
    public ConfigurationManager(PluginBase plugin) {
        this.plugin = plugin;
        loadConfigs();
    }
    
    private void loadConfigs() {
        try {
            // Create plugin data folder
            if (!plugin.getDataFolder().exists()) {
                plugin.getDataFolder().mkdir();
            }
            
            // Load config.yml
            File configFile = new File(plugin.getDataFolder(), "config.yml");
            if (!configFile.exists()) {
                plugin.saveResource("config.yml", false);
            }
            this.config = new Config(configFile, Config.YAML);
            
            // Load messages.yml
            File messagesFile = new File(plugin.getDataFolder(), "messages.yml");
            if (!messagesFile.exists()) {
                plugin.saveResource("messages.yml", false);
            }
            this.messages = new Config(messagesFile, Config.YAML);
            
            plugin.getLogger().info("§aConfigurations loaded successfully!");
        } catch (Exception e) {
            plugin.getLogger().error("§cError loading configurations: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public void reload() {
        loadConfigs();
        plugin.getLogger().info("§aConfiguration reloaded!");
    }
    
    public String getMessage(String key) {
        return messages.getString(key, "&cMessage not found: " + key);
    }
    
    public String getMessage(String key, String... replacements) {
        String msg = getMessage(key);
        for (int i = 0; i < replacements.length; i += 2) {
            if (i + 1 < replacements.length) {
                msg = msg.replace(replacements[i], replacements[i + 1]);
            }
        }
        return msg;
    }
    
    // Daily Reward Methods
    public int getDailyRewardMoney() {
        return config.getInt("rewards.daily.money", 1000);
    }
    
    public int getDailyRewardStreakBonus() {
        return config.getInt("rewards.daily.streak-bonus", 100);
    }
    
    public int getWeeklyRewardMoney() {
        return config.getInt("rewards.weekly.money", 5000);
    }
    
    public int getWeeklyRewardStreakBonus() {
        return config.getInt("rewards.weekly.streak-bonus", 500);
    }
    
    public int getMonthlyRewardMoney() {
        return config.getInt("rewards.monthly.money", 15000);
    }
    
    public int getMonthlyRewardStreakBonus() {
        return config.getInt("rewards.monthly.streak-bonus", 2000);
    }
    
    // Get reward items
    public Object getDailyRewardItems() {
        return config.get("rewards.daily.items", new LinkedHashMap<>());
    }
    
    public Object getWeeklyRewardItems() {
        return config.get("rewards.weekly.items", new LinkedHashMap<>());
    }
    
    public Object getMonthlyRewardItems() {
        return config.get("rewards.monthly.items", new LinkedHashMap<>());
    }
    
    public Config getConfig() {
        return config;
    }
    
    public Config getMessages() {
        return messages;
    }
}
