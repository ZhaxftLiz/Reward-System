package com.rewardsystem.managers;

public class CooldownManager {
    
    private static final long DAILY_COOLDOWN = 24 * 60 * 60 * 1000; // 24 hours
    private static final long WEEKLY_COOLDOWN = 7 * 24 * 60 * 60 * 1000; // 7 days
    private static final long MONTHLY_COOLDOWN = 30 * 24 * 60 * 60 * 1000; // 30 days
    
    public boolean canClaimDaily(long lastClaim) {
        long currentTime = System.currentTimeMillis();
        return currentTime - lastClaim >= DAILY_COOLDOWN;
    }
    
    public boolean canClaimWeekly(long lastClaim) {
        long currentTime = System.currentTimeMillis();
        return currentTime - lastClaim >= WEEKLY_COOLDOWN;
    }
    
    public boolean canClaimMonthly(long lastClaim) {
        long currentTime = System.currentTimeMillis();
        return currentTime - lastClaim >= MONTHLY_COOLDOWN;
    }
    
    public long getRemainingDailyTime(long lastClaim) {
        long currentTime = System.currentTimeMillis();
        long remaining = DAILY_COOLDOWN - (currentTime - lastClaim);
        return Math.max(0, remaining);
    }
    
    public long getRemainingWeeklyTime(long lastClaim) {
        long currentTime = System.currentTimeMillis();
        long remaining = WEEKLY_COOLDOWN - (currentTime - lastClaim);
        return Math.max(0, remaining);
    }
    
    public long getRemainingMonthlyTime(long lastClaim) {
        long currentTime = System.currentTimeMillis();
        long remaining = MONTHLY_COOLDOWN - (currentTime - lastClaim);
        return Math.max(0, remaining);
    }
    
    public String formatTime(long milliseconds) {
        long seconds = milliseconds / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        
        if (days > 0) {
            return days + " day(s) " + (hours % 24) + " hour(s)";
        } else if (hours > 0) {
            return hours + " hour(s) " + (minutes % 60) + " minute(s)";
        } else if (minutes > 0) {
            return minutes + " minute(s) " + (seconds % 60) + " second(s)";
        } else {
            return seconds + " second(s)";
        }
    }
}
