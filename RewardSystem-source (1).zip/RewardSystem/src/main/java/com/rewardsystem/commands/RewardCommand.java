package com.rewardsystem.commands;

import cn.nukkit.Player;
import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import com.rewardsystem.RewardSystem;
import com.rewardsystem.gui.RewardMenu;

public class RewardCommand extends Command {
    
    private RewardSystem plugin;
    private RewardMenu menu;
    
    public RewardCommand(RewardSystem plugin) {
        super("reward");
        this.plugin = plugin;
        this.menu = new RewardMenu(plugin);
        
        this.setDescription("Open reward menu or manage rewards");
        this.setUsage("/reward [reload|reset|info]");
        this.setPermission("rewardsystem.use");
    }
    
    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        
        // Check if sender has permission
        if (!sender.hasPermission("rewardsystem.use") && !sender.hasPermission("rewardsystem.admin")) {
            sender.sendMessage(plugin.getConfigManager().getMessage("messages.no-permission"));
            return false;
        }
        
        if (args.length == 0) {
            // Open menu for player
            if (!(sender instanceof Player)) {
                sender.sendMessage("§cThis command can only be run by a player!");
                return false;
            }
            
            Player player = (Player) sender;
            menu.openMainMenu(player);
            return true;
        }
        
        String subcommand = args[0].toLowerCase();
        
        switch (subcommand) {
            case "reload":
                return handleReload(sender);
                
            case "reset":
                return handleReset(sender, args);
                
            case "info":
                return handleInfo(sender, args);
                
            default:
                sender.sendMessage("§cUnknown subcommand: " + subcommand);
                return false;
        }
    }
    
    private boolean handleReload(CommandSender sender) {
        if (!sender.hasPermission("rewardsystem.admin")) {
            sender.sendMessage(plugin.getConfigManager().getMessage("messages.no-permission"));
            return false;
        }
        
        try {
            plugin.getConfigManager().reload();
            sender.sendMessage("§a✓ Reward system configuration reloaded successfully!");
            return true;
        } catch (Exception e) {
            sender.sendMessage("§cError reloading configuration: " + e.getMessage());
            return false;
        }
    }
    
    private boolean handleReset(CommandSender sender, String[] args) {
        if (!sender.hasPermission("rewardsystem.admin")) {
            sender.sendMessage(plugin.getConfigManager().getMessage("messages.no-permission"));
            return false;
        }
        
        if (args.length < 2) {
            sender.sendMessage("§cUsage: /reward reset <player>");
            return false;
        }
        
        String playerName = args[1];
        
        try {
            plugin.getDataManager().resetPlayerData(playerName);
            sender.sendMessage("§a✓ Reset reward data for player: §e" + playerName);
            
            Player player = plugin.getServer().getPlayer(playerName);
            if (player != null && player.isOnline()) {
                player.sendMessage("§a✓ Your reward data has been reset by an admin!");
            }
            
            return true;
        } catch (Exception e) {
            sender.sendMessage("§cError resetting player data: " + e.getMessage());
            return false;
        }
    }
    
    private boolean handleInfo(CommandSender sender, String[] args) {
        if (!sender.hasPermission("rewardsystem.admin")) {
            sender.sendMessage(plugin.getConfigManager().getMessage("messages.no-permission"));
            return false;
        }
        
        if (args.length < 2) {
            sender.sendMessage("§cUsage: /reward info <player>");
            return false;
        }
        
        String playerName = args[1];
        
        try {
            var data = plugin.getDataManager().getPlayerData(playerName);
            
            sender.sendMessage("§6=== Reward Info for " + playerName + " ===");
            sender.sendMessage("§7Daily Streak: §e" + data.getDailyStreak() + " §7(Total: §e" + data.getTotalDailyClaims() + "§7)");
            sender.sendMessage("§7Weekly Streak: §e" + data.getWeeklyStreak() + " §7(Total: §e" + data.getTotalWeeklyClaims() + "§7)");
            sender.sendMessage("§7Monthly Streak: §e" + data.getMonthlyStreak() + " §7(Total: §e" + data.getTotalMonthlyClaims() + "§7)");
            
            // Time information
            long dailyRemaining = plugin.getCooldownManager().getRemainingDailyTime(data.getLastDailyClaim());
            long weeklyRemaining = plugin.getCooldownManager().getRemainingWeeklyTime(data.getLastWeeklyClaim());
            long monthlyRemaining = plugin.getCooldownManager().getRemainingMonthlyTime(data.getLastMonthlyClaim());
            
            sender.sendMessage("§7Daily Cooldown: " + (dailyRemaining > 0 ? "§c" + plugin.getCooldownManager().formatTime(dailyRemaining) : "§aReady"));
            sender.sendMessage("§7Weekly Cooldown: " + (weeklyRemaining > 0 ? "§c" + plugin.getCooldownManager().formatTime(weeklyRemaining) : "§aReady"));
            sender.sendMessage("§7Monthly Cooldown: " + (monthlyRemaining > 0 ? "§c" + plugin.getCooldownManager().formatTime(monthlyRemaining) : "§aReady"));
            
            return true;
        } catch (Exception e) {
            sender.sendMessage("§cError getting player info: " + e.getMessage());
            return false;
        }
    }
}
