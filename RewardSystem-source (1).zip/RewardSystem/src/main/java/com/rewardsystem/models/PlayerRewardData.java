package com.rewardsystem.models;

public class PlayerRewardData {
    
    private String playerName;
    private long lastDailyClaim;
    private long lastWeeklyClaim;
    private long lastMonthlyClaim;
    private int dailyStreak;
    private int weeklyStreak;
    private int monthlyStreak;
    private int totalDailyClaims;
    private int totalWeeklyClaims;
    private int totalMonthlyClaims;
    
    public PlayerRewardData(String playerName) {
        this.playerName = playerName;
        this.lastDailyClaim = 0;
        this.lastWeeklyClaim = 0;
        this.lastMonthlyClaim = 0;
        this.dailyStreak = 0;
        this.weeklyStreak = 0;
        this.monthlyStreak = 0;
        this.totalDailyClaims = 0;
        this.totalWeeklyClaims = 0;
        this.totalMonthlyClaims = 0;
    }
    
    // Getters and Setters
    public String getPlayerName() {
        return playerName;
    }
    
    public long getLastDailyClaim() {
        return lastDailyClaim;
    }
    
    public void setLastDailyClaim(long lastDailyClaim) {
        this.lastDailyClaim = lastDailyClaim;
    }
    
    public long getLastWeeklyClaim() {
        return lastWeeklyClaim;
    }
    
    public void setLastWeeklyClaim(long lastWeeklyClaim) {
        this.lastWeeklyClaim = lastWeeklyClaim;
    }
    
    public long getLastMonthlyClaim() {
        return lastMonthlyClaim;
    }
    
    public void setLastMonthlyClaim(long lastMonthlyClaim) {
        this.lastMonthlyClaim = lastMonthlyClaim;
    }
    
    public int getDailyStreak() {
        return dailyStreak;
    }
    
    public void setDailyStreak(int dailyStreak) {
        this.dailyStreak = dailyStreak;
    }
    
    public int getWeeklyStreak() {
        return weeklyStreak;
    }
    
    public void setWeeklyStreak(int weeklyStreak) {
        this.weeklyStreak = weeklyStreak;
    }
    
    public int getMonthlyStreak() {
        return monthlyStreak;
    }
    
    public void setMonthlyStreak(int monthlyStreak) {
        this.monthlyStreak = monthlyStreak;
    }
    
    public int getTotalDailyClaims() {
        return totalDailyClaims;
    }
    
    public void setTotalDailyClaims(int totalDailyClaims) {
        this.totalDailyClaims = totalDailyClaims;
    }
    
    public int getTotalWeeklyClaims() {
        return totalWeeklyClaims;
    }
    
    public void setTotalWeeklyClaims(int totalWeeklyClaims) {
        this.totalWeeklyClaims = totalWeeklyClaims;
    }
    
    public int getTotalMonthlyClaims() {
        return totalMonthlyClaims;
    }
    
    public void setTotalMonthlyClaims(int totalMonthlyClaims) {
        this.totalMonthlyClaims = totalMonthlyClaims;
    }
}
